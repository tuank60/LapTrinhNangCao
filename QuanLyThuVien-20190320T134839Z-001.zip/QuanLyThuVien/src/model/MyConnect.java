
package model;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class MyConnect {
    private String className;
    private String url;
    private String user;
    private String password;
    
    public Connection getConnection() throws IOException{
        Connection conn;
        
        Properties p = new Properties();
        p.load(new FileInputStream("config.properties"));
        className = p.getProperty("CLASSNAME");
        url = p.getProperty("URL");
        user = p.getProperty("USER");
        password = p.getProperty("PASSWORD");
        
        try {
            // Khai báo tên driver (tên Class) để kết nối với hệ quản trị cơ sở dữ liệu MYSQL
            Class.forName(className);
            // Lấy về kết nối
            conn =DriverManager.getConnection(url,user,password); 
            return conn;
        } catch (Exception e) {
            // Ket noi khong thanh cong, hien thi loi
            e.printStackTrace();
        }
        return null;
    }
    
}
